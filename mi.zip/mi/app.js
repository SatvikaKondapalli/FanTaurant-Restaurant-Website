const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcrypt"); // For password encryption

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cors());
app.use(express.static("public")); // Serve frontend files

// ✅ MongoDB Connection
mongoose.connect("mongodb://localhost:27017/FanTaurant")
    .then(() => console.log("✅ Connected to MongoDB"))
    .catch(err => console.error("❌ MongoDB Connection Error:", err));

// ✅ User Schema (For Signup & Login)
const userSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
    email: String,
    password: String, // Hashed password
});

const User = mongoose.model("User", userSchema);

// ✅ Reservation Schema
const reservationSchema = new mongoose.Schema({
    date: String,
    time: String,
    name: String,
    phone: String,
    persons: Number,
});

const Reservation = mongoose.model("Reservation", reservationSchema);

// ✅ API Route for Signup (Register Users)
app.post("/api/signup", async (req, res) => {
    try {
        const { firstName, lastName, email, password } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: "User already exists" });
        }

        // Hash password before saving
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ firstName, lastName, email, password: hashedPassword });

        await newUser.save();
        res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
        res.status(500).json({ error: "Signup failed" });
    }
});

// ✅ API Route for Login (Authenticate Users)
app.post("/api/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find user by email
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        // Compare password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        res.status(200).json({ message: "Login successful", firstName: user.firstName });
    } catch (error) {
        res.status(500).json({ error: "Login failed" });
    }
});

// ✅ API Route to Store Reservations
app.post("/api/reservations", async (req, res) => {
    try {
        const { date, time, name, phone, persons } = req.body;
        const newReservation = new Reservation({ date, time, name, phone, persons });
        await newReservation.save();
        res.status(201).json({ message: "Reservation successful!" });
    } catch (error) {
        res.status(500).json({ error: "Failed to save reservation" });
    }
});

// ✅ API Route to Delete All Reservations (For Testing)
app.delete("/api/reservations", async (req, res) => {
    try {
        await Reservation.deleteMany({});
        res.json({ message: "All reservations deleted successfully!" });
    } catch (error) {
        res.status(500).json({ error: "Failed to delete reservations" });
    }
});
// ✅ Get all registered users (excluding passwords)
app.get("/api/users", async (req, res) => {
    try {
        const users = await User.find({}, "-password"); // Exclude passwords
        res.json(users);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch users" });
    }
});

// ✅ Get all table reservations
app.get("/api/reservations", async (req, res) => {
    try {
        const reservations = await Reservation.find();
        res.json(reservations);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch reservations" });
    }
});

// ✅ Start Server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
